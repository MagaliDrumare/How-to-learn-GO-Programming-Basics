package main

import ("fmt"
"io/ioutil"
"net/http")

func main() {
	resp, _ := http.Get("https://www.washingtonpost.com/news-sitemap-index.xml")
	bytes, _ := ioutil.ReadAll(resp.Body)
	string_body := string(bytes)
	fmt.Println(string_body)
	resp.Body.Close()
}





// To access data online, you need to first make a request.
// within that response you can get the content itself, which is in byte form
// To then begin working with it, generally, you will want to convert the byes to string
// You'll want to close that response.Body to make sure we free up the resources.