package main

import (
    "fmt"
    "sync"
)

var wg sync.WaitGroup

func foo(c chan int, someValue int) {
    defer wg.Done()
    c <- someValue * 5
}

func main() {
    fooVal := make(chan int, 10)
    for i := 0; i < 10; i++ {
        wg.Add(1)
        go foo(fooVal, i)
    }
    wg.Wait()
    close(fooVal)
    for item := range fooVal {
        fmt.Println(item)
    }
}


// Video 22 : Go channels 
// Go Channels to connect concurrent goroutines, 
//in order to send and receive values between them, using the channel operator <-
// pass the value through the channel 
// To send the value over a channel, you would do c <- v. 
// To receive a value from a channel, you would do var := <-c.


// video 23 : Buffering and Iterating over Channels 
// "sync"
// create the variable : var wg sync.WaitGroup
// wg.Add(1) before rhe routine go foo(fooVal, i)
// wg.Wait() at the end of the go routine
// defer wg.Done() in the function
// add buffer add 10 : fooVal := make(chan int,10)
