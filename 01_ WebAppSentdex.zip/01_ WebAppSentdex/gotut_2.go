
package main 

import ("fmt"
	"math/rand")

func main() {

fmt.Println("A number from 1-100", rand.Intn(100))

}