
package main 

import(
"time"
"fmt"
"sync"
)

var wg sync.WaitGroup

func says(s string){
	defer wg.Done()
	for i :=0; i<3; i++ {
		fmt.Println(s)
		time.Sleep(time.Millisecond*100)
	}
	
}

func main(){
 wg.Add(1)
 go says("Hey")
 wg.Add(1)
 go says("There")
 wg.Wait()
}

// video 18 : Go routines 
	// Concurrency concept : dealing with multiple things at a multiple time 
	// Concurrency made thanks with Goroutines 
	// Add go in front of the line of code 
	// import sync


// video 19 : Synchronize go routines 
	// create var wg sync.WaitGroup
	// wg.Add(1) before each go routines 
	// wg.Wait() at the end of the go routines 
	// Very important : wg.Done() at the end of the function. 


// video 20 
	// The idea of the defer statement is to put off (defer) 
    //the execution of something until the surrounding function is done. 
	// defer wg.Done() instead of wg.Done() 

```package main 
import ("fmt")

func foo(){
	defer fmt.Println("Done!")
	defer fmt.Println("Are we Done?")
	fmt.Println("Doing some stuff, who knows what?")
}

func main(){
	foo()
}




