// key and value maps 

package main 

import "fmt"

func main(){

grades := make(map[string]float32)

grades["Timmy"] = 42 
grades["Jess"] = 92
grades["Magali"] = 75

fmt.Println(grades)

 TimsGrade :=grades["Timmy"]
 fmt.Println(TimsGrade)

 delete(grades,"Timmy")
 fmt.Println(grades)

for k,v := range grades {

	fmt.Println(k,":",v)
}


}

// to analyse the code gofmt mapping14.go 
// create tour ow type with struct next tutorial 
