// Concurrency concept : dealing with multiple things at a multiple time 
// Concurrency made thanks with Goroutines 
// Add go in front of the line of code 

package main 

import(
"time"
"fmt"
)


func says(s string){
	for i :=0; i<3; i++ {
		fmt.Println(s)
		time.Sleep(time.Millisecond*100)
	}
}

func main(){
 go says("Hey")
 go says("There")

 time.Sleep(time.Second)
}


