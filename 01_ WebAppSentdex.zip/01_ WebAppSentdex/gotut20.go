
package main 

import(
"time"
"fmt"
"sync"
)

var wg sync.WaitGroup

func cleanup(){
	if r:=recover(); r!=nil{
		fmt.Println("Recovered in cleanup",r)
	}
	wg.Done()
	}

func say(s string) {
	defer cleanup()
	for i := 0; i < 3; i++ {
		time.Sleep(100*time.Millisecond)
		fmt.Println(s)
		if i == 2 {
			panic("Oh dear... a 2")
		}
	}	
}

func main() {
	wg.Add(1)
	go say("Hey")
	wg.Add(1)
	go say("there")
	wg.Wait()
}
// video 18 : Go routines 
	// Concurrency concept : dealing with multiple things at a multiple time 
	// Concurrency made thanks with Goroutines 
	// Add go in front of the line of code 
	// import sync


// video 19 : Synchronize go routines 
	//Create var wg sync.WaitGroup
	//wg.Add(1) before each go routines 
	//wg.Wait() at the end of the go routines 
	//Very important : wg.Done() at the end of the function. 


// video 20 : Defer Statement 
	//The idea of the defer statement is to put off (defer) 
    //The execution of something until the surrounding function is done. 
	//defer wg.Done() instead of wg.Done() 

 // video 21 : Panic and Recover function 
	//Panic : The idea of panic is to halt the program and start to panic. 
    //This will stop the running function and run all of the deferred functions from the panicking function. 
    //The recover function lets you recover from a panicking goroutine.





