package main

import (
  "encoding/xml"
  "fmt"
  "io/ioutil"
  "net/http"
)

type Sitemapindex struct {
  Locations []string `xml:"sitemap>loc"`
}

type News struct {
  Titles []string `xml:"url>news>title"`
  Keywords []string `xml:"url>news>keywords"`
  Locations []string `xml:"url>loc"`
}

// type NewsMap of 
type NewsMap struct {
  Keyword string
  Location string
}

func main() {
  var s Sitemapindex
  var n News
  resp, _ := http.Get("https://www.washingtonpost.com/news-sitemap-index.xml")
  bytes, _ := ioutil.ReadAll(resp.Body)
  xml.Unmarshal(bytes, &s)
  // initialization of the map 'news_map' of type NewsMap
  news_map := make(map[string]NewsMap)

  for _, Location := range s.Locations {
    resp, _ := http.Get(Location)
    bytes, _ := ioutil.ReadAll(resp.Body)
    xml.Unmarshal(bytes, &n)


    for idx, _ := range n.Keywords {
      // incrementation of the map (key = idx, values = n.Keywords[idx], n.Locations[idx] 
      // respect the order in NewsMap Struct 
      news_map[n.Titles[idx]] = NewsMap{n.Keywords[idx], n.Locations[idx]}
    }
  }
  // for key idx, value data in the map news_map
  for idx, data := range news_map {
    fmt.Println("\n\n\n\n\n",idx)
    fmt.Println("\n",data.Keyword)
    fmt.Println("\n",data.Location)
  }
}

// Create a map type with struct 