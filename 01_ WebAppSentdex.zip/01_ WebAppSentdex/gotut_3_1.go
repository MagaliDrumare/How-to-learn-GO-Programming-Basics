package main 


import("fmt")


func add(x,y float32) float32 {
	
	return x+y
}


func main () {

 var num1 float32 = 5.6 
 var num2 float32 = 9.5 

 fmt.Println(add(num1,num2))

}