//Pointer 

package main 

import "fmt"

func main() {

	x := 15 
	a := &x //memory adress 
	fmt.Println(a)
	fmt.Println(*a)
}