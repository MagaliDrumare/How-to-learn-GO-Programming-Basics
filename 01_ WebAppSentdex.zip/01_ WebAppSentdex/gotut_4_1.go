//Pointer 

package main 

import "fmt"

func main() {

	x := 15 
	a := &x //memory adress 
	fmt.Println(a) // read the memory
	fmt.Println(*a) // read the value of the memory 
	*a = 5 
	fmt.Println(x)
}