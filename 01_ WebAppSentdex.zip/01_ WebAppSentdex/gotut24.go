package main 

import (
	"fmt"
	"net/http"
	"html/template"
	"io/ioutil"
	"encoding/xml"
  "sync"
)

var wg sync.WaitGroup

type Sitemapindex struct {
  Locations []string `xml:"sitemap>loc"`
}

type News struct {
  Titles []string `xml:"url>news>title"`
  Keywords []string `xml:"url>news>keywords"`
  Locations []string `xml:"url>loc"`
}

// type NewsMap of 
type NewsMap struct {
  Keyword string
  Location string
}


type NewsAggPage struct {
	Title string 
	News map[string]NewsMap 
}

func newsRoutine(c chan News, Location string){
  defer wg.Done()
  var n News
  resp, _ := http.Get(Location)
  bytes, _ := ioutil.ReadAll(resp.Body)
  xml.Unmarshal(bytes, &n)
  resp.Body.Close()
  c<-n
}

func newsAggHandler(w http.ResponseWriter, r *http.Request) {
  var s Sitemapindex
  resp, _ := http.Get("https://www.washingtonpost.com/news-sitemap-index.xml")
  bytes, _ := ioutil.ReadAll(resp.Body)
  xml.Unmarshal(bytes, &s)
  // initialization of the map 'news_map' of type NewsMap
  news_map := make(map[string]NewsMap)
  resp.Body.Close()
  queue :=make(chan News,30)


  for _, Location := range s.Locations {
    wg.Add(1)
    go newsRoutine(queue, Location)

    }
    wg.Wait()
    close(queue)

  for elem:=range queue{
  for idx, _ := range elem.Keywords {
      news_map[elem.Titles[idx]] = NewsMap{elem.Keywords[idx], elem.Locations[idx]}
   }

  }
  	p:=NewsAggPage{Title : "Amazing news Aggregator", News : news_map}
  	t,_:= template.ParseFiles("newsaggtemplate.html")
  	t.Execute(w,p)

}

func indexHandler(w http.ResponseWriter, r *http.Request) {
  	fmt.Fprintf(w, "<h1>Whoa, Go is neat!</h1>")
}



func main(){
	http.HandleFunc("/", indexHandler)
	http.HandleFunc("/agg/", newsAggHandler)
	http.ListenAndServe(":8000", nil)
}


// Video 24 : Adding concurrency to speed up the App
// Import "sync"
// Create a func newsRoutine that will be called with the instruction : go newsRoutine(queue, Location)
// Create a channel queue : queue :=make(chan News,30)
// Pass n the result of the xml.Unmarshal(bytes, &n) into the channel queue -> c<-n
// Buffering = 30 -> queue :=make(chan News,30)
// Iterate inside queue : for elem:=range queue{}
// Replace n.keywords by elem.Keywords (all the n by elem)
// Synchronize the routines : 
  // create var wg sync.WaitGroup
  //add wg.Add(1) before the go routine go newsRoutine(queue, Location)
  //add wg.Wait() and close the channel close(queue) after the go routines 
  //add defer wg.Done() in the func newsRoutine




