// Concept of Structs 
// No Class in GO 

package main 

import "fmt" 

type car struct {
	pedal uint16 // min 0 max 65535
	brake uint16
	wheel int16 //-32K - +32K 
	speed float64
}

func main(){
	a_car := car{pedal: 22341, 
		brake: 0, 
		wheel: 12561, 
		speed: 255.0}

	//a_car := car {22341,0,12561,225.0}
fmt.Println("pedal:",a_car.pedal, "brake:",a_car.brake,"wheel:",a_car.wheel)
}

