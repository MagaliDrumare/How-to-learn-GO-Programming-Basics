// Webdev Basic 

package main 

import("fmt" 
"net/http")

func index_handler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w,"<h1>Good morning Vietnam!</h1>")
	fmt.Fprintf(w,"<p>Bonjour la France </p>")
	fmt.Fprintf(w,"<p>Buenas Tardes Barcelona</p>")
	fmt.Fprintf(w,"<p>Buenas Tardes Barcelona</p>")
	fmt.Fprintf(w,"<p>You %s even add %s</p>","can", "<strong>variables</strong>")

}

func main() {
	http.HandleFunc("/", index_handler)
	http.ListenAndServe(":8000", nil)
}

// access http://localhost:8000

