

package main 

import "fmt"

type person struct {

firstName string 
lastName string 


}


func main() {

	// alex :=person{"Alex","Ferguson"}
	alex:=person{firstName: "Alex",lastName:"Fergusson"}
	fmt.Println(alex)

}



// data structure : a collection of properties 
// that are related together. 

// initialize a struct : type person struct 