
package main 

import "fmt" 

func main(){

	mySlice:=[]string{ "Hi", "There", "How"}
	updateSlice(mySlice)
	fmt.Println(mySlice)
}

func updateSlice(s []string){
	s[0]="Bye"
}


// Data structure : a collection of properties 
// that are related together. 

// Initialize a struct : type person struct 
//type person struct {
//firstName string 
//lastName string 
//}

// Call a data structuture 
// alex:=person{fisrtName: "Alex", lastName: "Fergusson"}
// var alex person -> alex.fisrtName="Alex" alex.lastName="Anderson"
 
// Embbed structure into structure 
// type contactInfo struct
// contact  contactInfo inside type person struct 
// contact : contactInfo{}, 
// Do not forget the "," after each value of the struct 

// Pointers in GO 
// Go update the copy 
// jimPointer :=&jim -> jimPointer access of the memory of jim 
// *person we are working on the pointer to a person 
// * pointerToPerson is an operator = we want to manipulate the value, the pointer is referencing. 

// need to use a pointer (value)
// int float string bool struct 

// no need to use a pointer (structure)
// slices maps channels pointers functions 
// with slice "Hi" is remplaced by "Bye"







