

package main 

import "fmt"

type person struct {

firstName string 
lastName string 


}


func main() {

	var alex person
	
	alex.firstName="Alex"
	alex.lastName="Anderson"
	fmt.Println(alex)

}



// data structure : a collection of properties 
// that are related together. 

// initialize a struct : type person struct 
