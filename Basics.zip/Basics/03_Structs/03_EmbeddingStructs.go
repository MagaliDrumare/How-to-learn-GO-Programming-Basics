

package main 

import "fmt"


type contactInfo struct {
	email string 
	zipCode int 
}


type person struct {

firstName string 
lastName string 
contact  contactInfo

}

func main() {

	jim:=person{
		firstName : "Jim",
		lastName : "Party",
		contact : contactInfo{

			email :"jim@gmail.com", 
			zipCode : 94000,
		},
	}

	fmt.Printf("+%v",jim)
}

// data structure : a collection of properties 
// that are related together. 

// initialize a struct : type person struct 
//type person struct {
//firstName string 
//lastName string 
//}

// call a data structuture 
// alex:=person{fisrtName: "Alex", lastName: "Fergusson"}
// var alex person -> alex.fisrtName="Alex" alex.lastName="Anderson"
 
// embbed structure into structure 
// type contactInfo struct
// contact  contactInfo inside type person struct 
// contact : contactInfo{}, 
// Do not forget the "," after each value of the struct 




