
package main 

import ("fmt"
		"net/http"
		"os"
		"io") 

func main() {

resp, err :=http.Get("http://google.com")
if err!=nil {
  fmt.Println("Error:", err)
  os.Exit(1)
}


io.Copy(os.Stout, resp.Body)



// create a byte slice
 //bs:=make([]byte,99999)
 // resp.Body.Read(bs)
 //fmt.Println(string(bs))

}

// Interface reader 
// Read function take the real source of data <!doctype html>....
// store it into a byte slice 

// io.Copy : 
// something that implement the reader interface : resp.Body
// reader interface out->in 
// something that iomplement the writer interface: os.Sout
// writer interface in->out


