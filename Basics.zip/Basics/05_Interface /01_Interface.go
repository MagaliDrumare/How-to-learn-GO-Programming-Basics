
package main 
import "fmt"


type bot interface{

	getGrettings()string
}

type englishBot struct {}
type spanishBot struct {}

func main (){

	eb :=englishBot{}
	sb :=spanishBot{}


printGreeting(eb)
printGreeting(sb)


}
 
func printGreeting(b bot){

fmt.Println(b.getGrettings())

}


func (eb englishBot) getGrettings() string {

	return "Hi There"
}

func (sb spanishBot) getGrettings() string {

	return "Hola"
}




//  Use interface when functions have the same logic! 
// 
