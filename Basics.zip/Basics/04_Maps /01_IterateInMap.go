
package main 

import "fmt" 

func main() {

	colors := map[string]string{
		"red": "#ff0000",
		"green": "#4bf745",
		"white": "#ffffff",
	}
  	printMap(colors)
}


func printMap(c map[string]string){

for color, hex :=range c {

	fmt.Println("hex code for",color,"is", hex)

	}

}

// map 
// key and value all the same type 
// colors := map[string]string{,,,}
// var colors map[string]string 
// colors :=make(map[string]string)
// colors :=make(map[int]string) -> colors[10]=" #ffffff"
// delete (colors, "white")


// make a forloop into a map 
//func printMap(c map[string]string){
//for color, hex :=range c { WRITE THE CODE}
//}

// Use a map versus a struct 
// map : all keys and all value must be the same type. 
// map : keys are indexed -can iterate over 
// map is a reference type no need of pointer


