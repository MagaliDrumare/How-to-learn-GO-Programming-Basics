 
package main 

import ("fmt" 
		"net/http")

func main(){

	links:=[]string{
		"http://google.com",
		"http://facebook.com",
		"http://stackoverflow.com",
		"http://golang.org",
		"http://amazon.com",
	}


	c :=make(chan string)

	for _, link :=range links {

		// listen the channel and print one 
		go checkLink(link,c)
	}
     
    for i:=0; i<len(links); i++{

    	fmt.Println(<-c)
 }
     
}

func checkLink(link string, c chan string){

	_, err := http.Get(link)
	if err!=nil {

		fmt.Println(link, "might be down")
		c<-"Might be down I think"
		
		return 
	}

    fmt.Println(link, "Yes it is up")
    c<-"Yes its up"
}

//Go Routines and Channel 
// channel : main routine is aware 
// when child routines ends with the code 
// channel must be of a same type : channel of type string (int)
// creation of a channel of type string -> c :=make(chan string)
// send data into a channel channel <-5 
// receive the value from the channel myNumber <-channel 
// a function can receive the value from the channel fmt.Println(<-channel)
