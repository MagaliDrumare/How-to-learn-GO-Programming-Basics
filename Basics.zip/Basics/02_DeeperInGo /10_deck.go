package main 
import ("fmt"
		"strings"
		"os"
		"io/ioutil")



type deck [] string 



func NewDeck() deck {

 cards:=deck{}

 cardSuits:=[]string{"Spades", "Diamonds", "Hearts"}
 cardValue:=[]string {"Ace","Two","Three","Four"}

for _, suit :=range cardSuits{
	for _,value :=range cardValue{

		cards=append(cards,value+"of"+suit)
	}
}

return cards


}


func (d deck) print(){

for i, card :=range d {

	fmt.Println(i,card)
	}

}


func deal(d deck, handSize int) (deck, deck) {

	return d[:handSize], d[handSize:]

}

func (d deck) toString() string {
	
	return strings.Join([]string(d), ",")

}

func (d deck) saveToFile(filename string) error {

	return ioutil.WriteFile(filename,[]byte(d.toString()),0666)

}


func newDeckFromFile(filename string)deck{

	// bs is for byte slice 
	bs,err :=ioutil.ReadFile(filename)
	if err!=nil{

		fmt.Println("Error", err)
		os.Exit(1)
	}

 
 s:=strings.Split(string(bs),",") // "Ace of Spades", "Two of Spades"
 return deck(s)


}


// Concept of byte 
// https://golang.org/pkg 
// Package ioutil 
// WriteFile(filename string, data[]byte, perm os.FileMode)error
// input byte slice : []byte
// Table of conversion asciitable.com 
// "Hi there"-> converted to a byte slice [72 105 32 116 104....] computer friendly representation. 
// Convert the string "Hi there" into a byte slice : []byte("Hi there") - type we want(value we have)


// String Convertion 
// []string(d)<-> ["tata","toto","titi"]-> "tata","toto","titi"
// import package strings : import "strings
// strings.Join<-> "tata","toto","titi" -> "tata, toto, titi"
// []byte(d.toString()) <-> "tata, toto, titi" -> a byte [123 13 15....]
// ioutil.WriteFile take the argument []byte(d.toString())

// Error Handling 
// id err!=nil{} if error is not nil then exceute the function. 
// import os package -> func Exit->func Exit (code 1) something goes wrong with the program


// FileName Convertion (opposite to String Convertion)
// create the byte slice (bs) from the filename bs,err :=ioutil.ReadFile(filename)
//  (string(bs),",")-> [123 13 15....]-> "tata, toto, titi" 
// strings.Split ->"tata, toto, titi" -> ["tata", "toto", titi"] 









