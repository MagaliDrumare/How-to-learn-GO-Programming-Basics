package main 


func main() {

	cards:= NewDeck()

	cards.print()

	}
	




// run at the same time main.go and desck.go 
//MacBook-Pro-de-DRUMARE:desktop magalidrumare$ go run main.go deck.go

