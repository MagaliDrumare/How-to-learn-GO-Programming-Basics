// executable file main
// reusable another name
// package declaration
package main

//import standard library fmt (paclage fmt)
import "fmt"

// declare function func
// name of the function main
// arguments()
// code running when the func is called{}
func main() {

	fmt.Println("Hi there")
}
