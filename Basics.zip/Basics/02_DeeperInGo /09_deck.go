package main 
import ("fmt"
		"strings"
		"io/ioutil")



type deck [] string 



func NewDeck() deck {

 cards:=deck{}

 cardSuits:=[]string{"Spades", "Diamonds", "Hearts"}
 cardValue:=[]string {"Ace","Two","Three","Four"}

for _, suit :=range cardSuits{
	for _,value :=range cardValue{

		cards=append(cards,value+"of"+suit)
	}
}

return cards


}


func (d deck) print(){

for i, card :=range d {

	fmt.Println(i,card)
	}

}


func deal(d deck, handSize int) (deck, deck) {

	return d[:handSize], d[handSize:]

}

func (d deck) toString() string {
	
	return strings.Join([]string(d), ",")

}

func (d deck) saveToFile(filename string) error {

	return ioutil.WriteFile(filename,[]byte(d.toString()),0666)

}

 
 // Concept of byte 
// https://golang.org/pkg 
//Package ioutil 
//WriteFile(filename string, data[]byte, perm os.FileMode)error
// input byte slice []byte
// table of conversion asciitable.com 
// "Hi there"-> converted to a byte slice [72 105 32 116 104....] computer friendly representation. 
// convert the string "Hi there" into a byte slice : []byte("Hi there") - type we want(value we have)


// String Convertion 
// []string(d)<-> ["tata","toto","titi"]
// convert a slice of string into a string 
// import package strings : import "strings"
// strings.Join([]string(d), ",") <-> ["tata","toto","titi"] -> "tata, toto, titi"


/// Write 
// 








