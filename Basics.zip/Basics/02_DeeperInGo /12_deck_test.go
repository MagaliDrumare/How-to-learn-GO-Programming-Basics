package main

import "testing"

func TestNewDeck(t *testing.T) {

	d := newDeck()

	if len(d) != 16 {

		t.Errorf("Expected deck lenght of 20, but got %v", len(d))

	}
}

// create a deck_test.go file
// xrite a test function func TestNewDeck(t *testing.T) 
//run go test in the console 