package main 

import "fmt"

func main() {

	card:=newCard()
	
	fmt.Println(card)
}

// define a function called newCards 
// when we execute a function 
//we return a value of type string 
func newCard() string{
    return "Five of Diamonds"
}