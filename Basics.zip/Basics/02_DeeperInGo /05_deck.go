package main 

// create a new type of deck 
// slice of strings 

type deck [] string 

// create a function print 

// any variable of type deck now have teh acces to the print method
// cards of type deck have acces to the the function deck cards.print()
// d is a receiver of type deck (copy of the deck we're working cards)

func (d deck) print(){

for i, card :=range d {

	fmt.PrintLn(i,card)
	}

}