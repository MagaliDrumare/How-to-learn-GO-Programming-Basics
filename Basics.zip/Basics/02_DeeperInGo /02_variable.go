package main

import "fmt"

func main() {

	// go is static language
	// var variable
	// name card
	// type string = static types
	// basic go types : bool, string,int, float64
	// assign the value : Ace of Spades
	//var card string = "Ace of Spades"
	card := "Ace of Spades"
	card = "Five of Diamonds"
	fmt.Println(card)
}
