package main 
import "fmt"

// create a new type of deck 
// slice of strings 

type deck [] string 

// create a function print 

// any variable of type deck now have teh acces to the print method
// cards of type deck have acces to the the function deck cards.print()
// d is a receiver of type deck (copy of the deck we're working cards)


func NewDeck() deck {

 cards:=deck{}

 cardSuits:=[]string{"Spades", "Diamonds", "Hearts"}
 cardValue:=[]string {"Ace","Two","Three","Four"}

for _, suit :=range cardSuits{
	for _,value :=range cardValue{

		cards=append(cards,value+"of"+suit)
	}
}

return cards


}


func (d deck) print(){

for i, card :=range d {

	fmt.Println(i,card)
	}

}