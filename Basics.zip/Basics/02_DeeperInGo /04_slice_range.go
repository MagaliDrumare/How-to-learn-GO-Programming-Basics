package main 

import "fmt"

func main() {
 // [] string define an array of type string 
//  {} contain the informations of the array 
	cards:=[]string{"Ace of diamonds", newCard()}
// how to pass an element to the array  : use append(name of the slice,element)
	cards=append(cards,"Six of Spades")

// i : index of the element in the array 
// card : current card we iterate over 
// range cards : take a slice of cards and iterate over it 
// fmt.Println(i,card) : run this code one time for each car in the slice. 
	for i, card :=range cards{
		fmt.Println(i,card)
	}
	
	fmt.Println(cards)
}

func newCard() string{
    return "Five of Diamonds"
}

// array fixed lenght list of things 
// slices is an extensible array 
// element in a sclice must be of the smae type 



