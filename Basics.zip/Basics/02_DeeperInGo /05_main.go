package main 

import "fmt"

func main() {
	cards:=deck{"Ace of diamonds", newCard()}
	cards=append(cards,"Six of Spades")

	cards.print()

	
	}
	
	fmt.Println(cards)
}

func newCard() string{
    return "Five of Diamonds"
}


// run at the same time main.go and desck.go 
//MacBook-Pro-de-DRUMARE:desktop magalidrumare$ go run main.go deck.go

