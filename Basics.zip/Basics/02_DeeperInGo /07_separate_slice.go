package main 


func main() {

	cards:= NewDeck()

	cards.print()

	hand,remainingCards := deal(cards,5)

	hand.print()
	remainingCards.print()


	}


	




// run at the same time main.go and desck.go 
//MacBook-Pro-de-DRUMARE:desktop magalidrumare$ go run main.go deck.go

