package main 
import "fmt"


type deck [] string 



func NewDeck() deck {

 cards:=deck{}

 cardSuits:=[]string{"Spades", "Diamonds", "Hearts"}
 cardValue:=[]string {"Ace","Two","Three","Four"}

for _, suit :=range cardSuits{
	for _,value :=range cardValue{

		cards=append(cards,value+"of"+suit)
	}
}

return cards


}


func (d deck) print(){

for i, card :=range d {

	fmt.Println(i,card)
	}

}


func deal(d deck, handSize int) (deck, deck) {

	return d[:handSize], d[handSize:]

}



//syntax of a slice 
// fruits :=[]string {"apple","banana","grape","orange"}
// fruits[0:2]->apple, banana (grappe is excluded)
// fruits [:2]-> apple, babana 
// fruits [2:]-> grappe, orange 


