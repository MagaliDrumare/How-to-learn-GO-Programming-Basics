package main 
import "fmt"


func main() {

	cards:= NewDeck()
	fmt.Println(cards.toString())



	}


//func main() {

	//greetings := "Hi there!"
	//fmt.Println([]byte(greetings))
	

// run at the same time main.go and desck.go 
//MacBook-Pro-de-DRUMARE:desktop magalidrumare$ go run main.go deck.go
//deck->[]string->string->[]byte

